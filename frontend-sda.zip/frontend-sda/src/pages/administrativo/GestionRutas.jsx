import React from "react";

const GestionRutas = () => {
  return (
    <div className="p-6">
      <h2 className="text-2xl text-warning font-bold mb-4">Gestión de Rutas</h2>
      <p>Aquí podrás gestionar las rutas logísticas de la empresa (próximamente).</p>
    </div>
  );
};

export default GestionRutas;